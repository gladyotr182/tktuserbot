# Asena Installer
[![Run on Repl.it](https://repl.it/badge/github/asenadev/installer)](https://repl.it/github/asenadev/installer)

HerokuAPI'si kullanılarak yapılmış Otomatik Asena Deploy'er

Asena Reposunu kontrol edin: https://github.com/Quiec/AsenaUserBot
## Kurulum
```sh
git clone https://github.com/AsenaDev/Installer
cd Installer
pip install -r requirements.txt
python3 -m asena_installer
```

## Geliştiriciler
[@Quiec](https://t.me/fusuf)

[@SelaxG](https://t.me/SelaxG)

## Lisans
Bu proje GPL-3.0 lisansı ile korunmaktadır.
